//: Playground - noun: a place where people can play

import UIKit

/* @@HP: test the dictionaty that has two ssame key, what will return when look up */




var te: Int  = 10

var stringsAsInts: [String:Int] = [
    "zero" : 0,
    "one" : 1,
//    "one" : 2,
    "three" : 3,
    "four" : 4,
    "five" : 5,
    "six" : 6,
    "seven" : 7,
    "eight" : 8,
    "nine" : 9
]

var a = stringsAsInts["nine"]

println(a)


stringsAsInts["one"]



