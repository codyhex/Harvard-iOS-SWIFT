//
//  main.swift
//  S65HW1
//
//  Created by HePeng on 6/29/15.
//  Copyright (c) 2015 HePeng. All rights reserved.
//

import Foundation

println("Exercise #.2 ")

HelloWorld()

println("Exercise #.3 ")

intArrayToEnglishWords(numbers: [7, 2, -13, 300, 6, 26])

println("Exercise #.4 ")

sumOfItemCosts(inputDic: ["Ham": 345, "Cheese": 115])

println("Exercise #.5 ")

primesOf([3, 1, -3, 27, 29, 3, 7, 2, 7, 83, 91])

primesOf_2([3, 1, -3, 27, 29, 3, 7, 2, 7, 83, 91])


